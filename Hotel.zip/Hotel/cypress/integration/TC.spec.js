/// <reference types="cypress" />


//import Login from "../POM/Login"


//const LoginPage = new Login()
//const Element = LoginPage.elements
//const credentials = require('../fixtures/login')

describe('Hotel selection', () => {

    beforeEach(() => {

        cy.visit('/')



    })


    it('Select hotel and proceed', () => {


        cy.get('.mr-2.text-base').click()
        cy.get('.flex.guestLogin').should('have.length', '1')
        cy.get('.flex.guestLogin').find('[type=email]').type('javed.toptal@gmail.com').invoke('val').should('match', /javed.toptal@gmail.com/)
        cy.get('.flex.guestLogin').find('[type=password]').type('javed2244')
        cy.get('.flex.guestLogin').find('[type=button]').contains('Continue').click()
        cy.get('[class="MuiSelect-root MuiSelect-select MuiSelect-selectMenu MuiSelect-outlined MuiInputBase-input MuiOutlinedInput-input"]')
            .first()
            // .should('have.text','Select Hostels')
            .click()

        cy.get('[role="option"]').contains('The Hosteller Delhi').click()

        cy.get('[class="MuiSelect-root MuiSelect-select MuiSelect-selectMenu MuiSelect-outlined MuiInputBase-input MuiOutlinedInput-input"]')
            .first()
            .should('have.text', 'The Hosteller Delhi')

        cy.get('[type="text"]').first().click({ force: true })

        cy.get('[role="dialog"]').last().should('have.length', '1')

        cy.get('.MuiIconButton-label-79').contains('26').click()

        cy.get('[role="dialog"]').contains('OK').click()

        cy.get('[type="text"]').last().click({ force: true })

        cy.get('[role="dialog"]').last().should('have.length', '1')

        cy.get('.MuiIconButton-label-158').contains('27').click({ force: true })

        cy.get('[role="dialog"]').contains('OK').click()

        cy.get('[class="MuiSelect-root MuiSelect-select MuiSelect-selectMenu MuiSelect-outlined MuiInputBase-input MuiOutlinedInput-input"]')
            .last()

            .click()

        cy.get('[role="option"]').contains('3').click()

        cy.get('.mt-5').first().click()

        new Cypress.Promise((resolve, reject) => {
            resolve(cy.url())
            cy.wait(5000)
            cy.get('[class="xs:min-w-max"]').contains('Rooms and Prices').click({ force: true })
        })
        cy.wait(3000)

        new Cypress.Promise((resolve, reject) => {
            resolve(cy.get('.price_container'))
            cy.get('.price_container').first().contains('Add 1st Bed').click()


        })

        cy.get('.mobile_cart_view > .flex').should('have.length', '1')

        cy.get('#review_cart_row0').contains('Review Booking').click()

        new Cypress.Promise((resolve, reject) => {
            resolve(cy.get('.py-3 > :nth-child(1) > .font-bold'))


        })


        cy.url().should('eq', 'https://www.thehosteller.com/review')


        cy.get('.py-3 > :nth-child(1) > .font-bold').should('have.text', 'The Hosteller Delhi')
        cy.get('[type="button"]').contains('Continue').click()

        cy.get('#demo-simple-select-outlined').click()

        cy.get('.MuiList-root').contains('Mr').click()

        cy.get('[placeholder="First Name"]').type('Talib').invoke('val').should('match', /Talib/)

        cy.get('[placeholder="Last Name"]').type('na').invoke('val').should('match', /na/)

        cy.get('[placeholder="Mobile Number"]').type('0322412300').invoke('val').should('match', /0322412300/)


        cy.get('[placeholder="Email Address"]').type('guest@gmail.com').invoke('val').should('match', /guest@gmail.com/)


        cy.get('[placeholder="Address"]').type('Uk 123 street').invoke('val').should('match', /Uk 123 street/)

        cy.get('.css-ackcql').first().click()

        cy.get('.css-26l3qy-menu').contains('Pakistan').click()


        cy.get('#react-select-3-input').click()

        cy.get('.css-26l3qy-menu').contains('Punjab').click()

        cy.get('.css-ackcql').last().click()

        cy.get('.css-26l3qy-menu').contains('Lahore').click()

        cy.get('[placeholder="PinCode"]').type('1212').invoke('val').should('match', /1212/)


        cy.get('.text-center > .MuiButtonBase-root').click()

        cy.wait(5000)


    })


})